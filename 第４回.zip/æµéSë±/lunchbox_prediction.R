library(ggplot2)
library(dplyr)

#データの読み込み
#for MAC
train=read.csv('train.csv',na.strings=c("", "NULL"))
#FOR PC
train=read.csv('train.csv',na.strings=c("", "NULL"),fileEncoding="UTF-8-BOM")

#データ構造を把握する
str(train)
View(train)
head(train)
tail(train)
class(train)
dim(train)


#time変数を作成
train$time=as.Date(train$datetime)
#売り上げ数の時系列を作成
ggplot(train,aes(x=time,y=y))+geom_line()+labs(x="時間",y="売り上げ数")+theme_gray(base_family = "HiraKakuPro-W3")

#売り上げ数とsoldout の散布図時を作成
ggplot(train,aes(x=soldout,y=y))+geom_point()+labs(x="sold out",y="y")

#売り上げ数とkcal の散布図時を作成
ggplot(train,aes(x=kcal,y=y))+geom_point()+labs(x="kcal",y="y")

#売り上げ数とprecipitation の散布図を作成 
ggplot(train,aes(x=precipitation,y=y))+geom_point()+labs(x="precipitation",y="y")

#売り上げ数とpayday の散布図を作成
ggplot(train,aes(x=factor(payday),y=y))+geom_point()+labs(x="payday",y="y")

#売り上げ数とtemperature の散布図を作成
ggplot(train,aes(x= temperature,y=y))+geom_point() +labs(x="temperature ",y="y")

#売り上げ数とtemperature の回帰直線の当てはめ
ggplot(train,aes(x= temperature,y=y))+geom_point()+geom_smooth(method="lm")

# 月 情報の抽出
library(lubridate) 
train$month= month(train$datetime)
train$month=factor(train$month)
train$year= year(train$datetime)
train$year= factor(train$year)

# 月ごとの売り上げ数barplot
ggplot(train,aes(x=month,y=y))+geom_point()+labs(x="month",y="y")

# 売り上げ数と曜日のboxplotを作成
train$week<-factor(train$week,levels=c("月","火","水","木","金"))
ggplot(train,aes(x=week,y=y,fill=week))+geom_boxplot()+labs(x="week",y="y")+theme_gray(base_family = "HiraKakuPro-W3")


train$week2<-factor(train$week,levels=c("Mon","Tue","Wen","Thu","Fri"))
ggplot(train,aes(x=week2,y=y,fill=week2))+geom_boxplot()+labs(x="week",y="y")


# 売り上げ数と天気のboxplotを作成
ggplot(train,aes(x=weather,y=y))+geom_boxplot()+labs(x="weather",y="demand")+theme_gray(base_family = "HiraKakuPro-W3")
ggplot(train,aes(x=weather,y=y,fill=weather))+geom_boxplot()+labs(x="weather",y="demand")+theme_gray(base_family = "HiraKakuPro-W3")

# 売り上げ数とeventのboxplotを作成
ggplot(train,aes(x=event,y=y))+geom_boxplot()+labs(x="event",y="demand")+theme_gray(base_family = "HiraKakuPro-W3")
ggplot(train,aes(x=event,y=y,fill=event))+geom_boxplot()+labs(x="event",y="demand")+theme_gray(base_family = "HiraKakuPro-W3")

# 売り上げ数とremarksのboxplot
ggplot(train,aes(x=remarks,y=y))+geom_boxplot()+labs(x="remarks",y="y")+theme_gray(base_family = "HiraKakuPro-W3")

# 売り上げ数とお楽しみの調査
train$group<- "not fun"
train$group[train$remarks=="お楽しみメニュー"]<- "fun"
train$group<-factor(train$group)

#お楽しみメニューの影響？
ggplot(train,aes(x=time,y=y))+geom_point()+geom_line()+geom_point(data=train[train$group == "fun",],color="red",size=3)


#ウィルコクソンの順位和検定
Fun=train %>%
  filter(group=="fun")

NotFun=train%>%
  filter(group== "not fun")

#お楽しみメニューの比較
ggplot(train,aes(x=group,y=y))+geom_boxplot()


#Rによるウィルコクソンの順位和検定
install.packages("exactRankTests", repos="http://cran.ism.ac.jp/") $ library(exactRankTests)
library(exactRankTests)  
wilcox.exact(Fun$y,NotFun$y,paired=F)


#"お楽しみメニュー"のある日データを保存する
write.csv(Fun,"Fun.csv",fileEncoding = "CP932")

#"カレーのある日を抽出する
train$group2 <- "not curry"
train$group2[train$remarks=="お楽しみメニュー" & grepl("カレー",train$name)] <- "curry"
train$group2<-factor(train$group2)

 

#モデルの作成
model1=lm(y~time,train)
summary(model1)
plot(train$time,predict(model1,train),col="red",type='l',ylim=c(0,180))
par(new=T)    
plot(train$time,train$y,type='l',ylim=c(0,180))


#モデル２の作成
model2=lm(y~time+week,train)
summary(model2)
plot(train$time,predict(model2,train),col="red",type='l',ylim=c(0,180))
par(new=T)    
plot(train$time,train$y,type='l',ylim=c(0,180))

#モデル３の作成
model3=lm(y~time+week+month,train)
summary(model3)
plot(train$time,predict(model3,train),col="red",type='l',ylim=c(0,180))
par(new=T)    
plot(train$time,train$y,type='l',ylim=c(0,180))

#モデル４の作成
model4=lm(y~time+week+month+temperature,train)
summary(model4)
plot(train$time,predict(model4,train),col="red",type='l',ylim=c(0,180))
par(new=T)    
plot(train$time,train$y,type='l',ylim=c(0,180))


#モデル５の作成
model5=lm(y~time+week+month+temperature+group,train)
summary(model5)
plot(train$time,predict(model5,train),col="red",type='l',ylim=c(0,180))
par(new=T)    
plot(train$time,train$y,type='l',ylim=c(0,180))

#モデル６の作成
model6=lm(y~time+week+month+temperature+group+group2,train)
summary(model6)
plot(train$time,predict(model6,train),col="red",type='l',ylim=c(0,180))
par(new=T)    
plot(train$time,train$y,type='l',ylim=c(0,180))

#2014年のデータのみ抽出
train2=train%>%
  filter(year=="2014")

#モデル7の作成
model7=lm(y~time+week+temperature+group+group2,train2)
summary(model7)
plot(train2$time,predict(model7,train2),col="red",type='l',ylim=c(0,180))
par(new=T)    
plot(train2$time,train2$y,type='l',ylim=c(0,180))


#testデータの評価
test=read.csv('test.csv',na.strings=c("", "NULL"))
test$time=as.Date(test$datetime)
test$month= month(test$datetime)
test$month=factor(test$month)
test$year= year(test$datetime)
test$year= factor(test$year)

test$group<- "not fun"
test$group[test$remarks=="お楽しみメニュー"]<- "fun"
test$group=factor(test$group)
test$group2 <- "not curry"
test$group2[test$remarks=="お楽しみメニュー" & grepl("カレー",test$name)] <- "curry"
test$group2=factor(test$group2)
#levels(test$month)<-levels(train$month)
#levels(test$year)<-levels(train$year)


#モデルを使って予測する
model8=lm(y~time+week+temperature+group+group2,train2)
summary(model8)
plot(train2$time,predict(model8,train2),col="red",type='l',ylim=c(0,180))
par(new=T)    
plot(train2$time,train2$y,type='l',ylim=c(0,180))
p=predict(model8,test)
write.csv(p,"prediction.csv",fileEncoding = "CP932")




library(caret)
model <- train(
  y~time+week+temperature+group+group2,
  tuneLength = 5,
  data = train, 
  method = "ranger",
  trControl = trainControl(
    method = "cv", 
    number = 5, 
    verboseIter = TRUE
  )
)
print(model)
model$bestTune
