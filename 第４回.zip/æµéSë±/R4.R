#の決定木パッケージのインストール
install.packages("readr")
install.packages("rpart")
install.packages("rpart.plot")
#パッケージの読み込み
library(readr)
library(rpart)
library(rpart.plot)
library(dplyr)

# データの読み込み
data=read.csv("house_rent.csv",header=TRUE)
str(data)

# モデルの作成
model = lm(rent~ ., data)
summary(model)

# P値を基準に変数を選択して、再度モデルを作成
new_data = data %>% 
  select(-higher_than_2, -southdirection, -AC, -bath_toilet, -style_bath)
model_new = lm(rent ~., new_data)
summary(model_new)

# ステップワイズ法による変数選択
data=read.csv("house_rent.csv",header=TRUE)
null_model <- lm(rent~1,  data      )
full_model <- lm(rent~., data   )
step_model <- step(null_model, scope = list(lower = null_model, upper = full_model), direction = "forward")
test_data=read.csv("house_rent_test.csv",header=TRUE)
predict(step_model, test_data)

#loans.csvを読み込む
loans=read.csv("loans.csv")

#決定木の作成
loan_model <- rpart(outcome~loan_amount+credit_score, data = loans, method = "class", control = rpart.control(cp = 0))
#樹形図パッケージを追加する
library(part.plot)
#樹形図の作成
rpart.plot(loan_model)

loan_model <- rpart(outcome~., data = loans, method = "class")
plotcp(loan_model)  

 
